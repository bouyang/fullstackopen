import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9f53af8e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f53af8e"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [blogTitle, setBlogTitle] = useState("");
  const [blogAuthor, setBlogAuthor] = useState("");
  const [blogUrl, setBlogUrl] = useState("");
  const addBlog = (event) => {
    event.preventDefault();
    createBlog({
      title: blogTitle,
      author: blogAuthor,
      url: blogUrl
    });
    setBlogTitle("");
    setBlogAuthor("");
    setBlogUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "formDiv", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Title:",
      /* @__PURE__ */ jsxDEV("input", { value: blogTitle, onChange: (event) => setBlogTitle(event.target.value), placeholder: "write blog title here" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
        lineNumber: 25,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
      lineNumber: 23,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Author:",
      /* @__PURE__ */ jsxDEV("input", { value: blogAuthor, onChange: (event) => setBlogAuthor(event.target.value), placeholder: "write blog author here" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
        lineNumber: 29,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
      lineNumber: 27,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Url:",
      /* @__PURE__ */ jsxDEV("input", { value: blogUrl, onChange: (event) => setBlogUrl(event.target.value), placeholder: "write blog url here" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
        lineNumber: 33,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
      lineNumber: 31,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "save" }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
      lineNumber: 36,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
    lineNumber: 22,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "5U/Z2vLYtJlOEzyiH183iHolmd8=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJjOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFCZCxTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJTCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDTSxZQUFZQyxhQUFhLElBQUlQLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNRLFNBQVNDLFVBQVUsSUFBSVQsU0FBUyxFQUFFO0FBRXpDLFFBQU1VLFVBQVdDLFdBQVU7QUFDekJBLFVBQU1DLGVBQWU7QUFFckJWLGVBQVc7QUFBQSxNQUNUVyxPQUFPVDtBQUFBQSxNQUNQVSxRQUFRUjtBQUFBQSxNQUNSUyxLQUFLUDtBQUFBQSxJQUNQLENBQUM7QUFFREgsaUJBQWEsRUFBRTtBQUNmRSxrQkFBYyxFQUFFO0FBQ2hCRSxlQUFXLEVBQUU7QUFBQSxFQUNmO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsV0FDYixpQ0FBQyxVQUFLLFVBQVVDLFNBQ1o7QUFBQSwyQkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVBLHVCQUFDLFdBQ0QsT0FBT04sV0FDUCxVQUFVTyxXQUFTTixhQUFhTSxNQUFNSyxPQUFPQyxLQUFLLEdBQ2xELGFBQVksMkJBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdtQztBQUFBLFNBTHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsU0FBRztBQUFBO0FBQUEsTUFFQSx1QkFBQyxXQUNDLE9BQU9YLFlBQ1AsVUFBVUssV0FBU0osY0FBY0ksTUFBTUssT0FBT0MsS0FBSyxHQUNuRCxhQUFZLDRCQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHc0M7QUFBQSxTQUwxQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUEsdUJBQUMsV0FDRCxPQUFPVCxTQUNQLFVBQVVHLFdBQVNGLFdBQVdFLE1BQU1LLE9BQU9DLEtBQUssR0FDaEQsYUFBWSx5QkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR2lDO0FBQUEsU0FMckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLE9BMUI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkJFLEtBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkU7QUFFTjtBQTZCQWQsR0FoRk1GLFVBQVE7QUFBQWlCLEtBQVJqQjtBQWtGTixlQUFlQTtBQUFRLElBQUFpQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJCbG9nRm9ybSIsImNyZWF0ZUJsb2ciLCJfcyIsImJsb2dUaXRsZSIsInNldEJsb2dUaXRsZSIsImJsb2dBdXRob3IiLCJzZXRCbG9nQXV0aG9yIiwiYmxvZ1VybCIsInNldEJsb2dVcmwiLCJhZGRCbG9nIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiXG5cbmNvbnN0IEJsb2dGb3JtID0gKHsgY3JlYXRlQmxvZyB9KSA9PiB7XG4gIGNvbnN0IFtibG9nVGl0bGUsIHNldEJsb2dUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2Jsb2dBdXRob3IsIHNldEJsb2dBdXRob3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtibG9nVXJsLCBzZXRCbG9nVXJsXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IGFkZEJsb2cgPSAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgY3JlYXRlQmxvZyh7XG4gICAgICB0aXRsZTogYmxvZ1RpdGxlLFxuICAgICAgYXV0aG9yOiBibG9nQXV0aG9yLFxuICAgICAgdXJsOiBibG9nVXJsLFxuICAgIH0pXG5cbiAgICBzZXRCbG9nVGl0bGUoJycpXG4gICAgc2V0QmxvZ0F1dGhvcignJylcbiAgICBzZXRCbG9nVXJsKCcnKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm1EaXZcIj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXthZGRCbG9nfT5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgVGl0bGU6XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB2YWx1ZT17YmxvZ1RpdGxlfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0QmxvZ1RpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPSd3cml0ZSBibG9nIHRpdGxlIGhlcmUnXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICBBdXRob3I6XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHZhbHVlPXtibG9nQXV0aG9yfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtldmVudCA9PiBzZXRCbG9nQXV0aG9yKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9J3dyaXRlIGJsb2cgYXV0aG9yIGhlcmUnXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIFVybDpcbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHZhbHVlPXtibG9nVXJsfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0QmxvZ1VybChldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj0nd3JpdGUgYmxvZyB1cmwgaGVyZSdcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+c2F2ZTwvYnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG4gICAgICA8L2Rpdj5cbiAgKVxufVxuLy8gY29uc3QgQmxvZ0Zvcm0gPSAoeyBvblN1Ym1pdCwgYmxvZ1RpdGxlLCBoYW5kbGVUaXRsZUNoYW5nZSwgYmxvZ0F1dGhvciwgaGFuZGxlQXV0aG9yQ2hhbmdlLCBibG9nVXJsLCBoYW5kbGVVcmxDaGFuZ2UgfSkgPT4ge1xuLy8gICByZXR1cm4gKFxuLy8gICAgIDxmb3JtIG9uU3VibWl0PXtvblN1Ym1pdH0+XG4vLyAgICAgICA8ZGl2PlxuLy8gICAgICAgICBUaXRsZTpcbi8vICAgICAgICAgICA8aW5wdXRcbi8vICAgICAgICAgICB2YWx1ZT17YmxvZ1RpdGxlfVxuLy8gICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUaXRsZUNoYW5nZX1cbi8vICAgICAgICAgLz5cbi8vICAgICAgIDwvZGl2PlxuLy8gICAgICAgPGRpdj5cbi8vICAgICAgICAgQXV0aG9yOlxuLy8gICAgICAgICAgIDxpbnB1dFxuLy8gICAgICAgICAgICAgdmFsdWU9e2Jsb2dBdXRob3J9XG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQXV0aG9yQ2hhbmdlfVxuLy8gICAgICAgICAgIC8+XG4vLyAgICAgICA8L2Rpdj5cbi8vICAgICAgIDxkaXY+XG4vLyAgICAgICAgIFVybDpcbi8vICAgICAgICAgICA8aW5wdXRcbi8vICAgICAgICAgICB2YWx1ZT17YmxvZ1VybH1cbi8vICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVXJsQ2hhbmdlfVxuLy8gICAgICAgICAvPlxuLy8gICAgICAgPC9kaXY+XG4gICAgICBcbi8vICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPnNhdmU8L2J1dHRvbj5cbi8vICAgICA8L2Zvcm0+XG4vLyAgIClcbi8vIH1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZ0Zvcm0iXSwiZmlsZSI6Ii9Vc2Vycy9vdXlhbmcvRG9jdW1lbnRzL0xhdW5jaCBTY2hvb2wvRnVsbFN0YWNrT3Blbi9ibG9nL2Jsb2ctZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZ0Zvcm0uanN4In0=