import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9f53af8e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f53af8e"; const useState = __vite__cjsImport3_react["useState"];
import blogService from "/src/services/blogs.js";
const Blog = ({
  blog,
  deleteBlog
}) => {
  _s();
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  const addLike = () => {
    const id = blog.id;
    const blogObject = {
      user: blog.user,
      title: blog.title,
      author: blog.author,
      url: blog.url,
      likes: blog.likes + 1
    };
    blogService.update(id, blogObject);
  };
  const deleteSpecificBlog = () => {
    const id = blog.id;
    deleteBlog(id);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: {
      ...hideWhenVisible,
      ...blogStyle
    }, className: "blog", children: [
      blog.title,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "view" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      ...showWhenVisible,
      ...blogStyle
    }, children: [
      blog.title,
      " by ",
      blog.author,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 58,
        columnNumber: 38
      }, this),
      "Likes: ",
      blog.likes,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: addLike, children: "like" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 59,
        columnNumber: 29
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 59,
        columnNumber: 68
      }, this),
      blog.url,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 60,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: deleteSpecificBlog, children: "delete" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 61,
        columnNumber: 61
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "hide" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
      lineNumber: 54,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx",
    lineNumber: 46,
    columnNumber: 10
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpEUixTQUFTQSxnQkFBZ0I7QUFFekIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLE9BQU9BLENBQUM7QUFBQSxFQUFFQztBQUFBQSxFQUFNQztBQUFXLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNQyxZQUFZO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsSUFDYkMsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxJQUNiQyxjQUFjO0FBQUEsRUFDaEI7QUFFQSxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSWIsU0FBUyxLQUFLO0FBRTVDLFFBQU1jLGtCQUFrQjtBQUFBLElBQUVDLFNBQVNILFVBQVUsU0FBUztBQUFBLEVBQUc7QUFDekQsUUFBTUksa0JBQWtCO0FBQUEsSUFBRUQsU0FBU0gsVUFBVSxLQUFLO0FBQUEsRUFBTztBQUV6RCxRQUFNSyxtQkFBbUJBLE1BQU07QUFDN0JKLGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBRUEsUUFBTU0sVUFBVUEsTUFBTTtBQUNwQixVQUFNQyxLQUFLaEIsS0FBS2dCO0FBTWhCLFVBQU1DLGFBQWE7QUFBQSxNQUNqQkMsTUFBTWxCLEtBQUtrQjtBQUFBQSxNQUNYQyxPQUFPbkIsS0FBS21CO0FBQUFBLE1BQ1pDLFFBQVFwQixLQUFLb0I7QUFBQUEsTUFDYkMsS0FBS3JCLEtBQUtxQjtBQUFBQSxNQUNWQyxPQUFPdEIsS0FBS3NCLFFBQVE7QUFBQSxJQUN0QjtBQUVBeEIsZ0JBQVl5QixPQUFPUCxJQUFJQyxVQUFVO0FBQUEsRUFDbkM7QUFFQSxRQUFNTyxxQkFBcUJBLE1BQU07QUFDL0IsVUFBTVIsS0FBS2hCLEtBQUtnQjtBQUNoQmYsZUFBV2UsRUFBRTtBQUFBLEVBQ2Y7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLE9BQU87QUFBQSxNQUFDLEdBQUdMO0FBQUFBLE1BQWlCLEdBQUdSO0FBQUFBLElBQVMsR0FBRyxXQUFVLFFBQ3ZESDtBQUFBQSxXQUFLbUI7QUFBQUEsTUFDTix1QkFBQyxZQUFPLFNBQVNMLGtCQUFrQixvQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLFNBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPO0FBQUEsTUFBQyxHQUFHRDtBQUFBQSxNQUFpQixHQUFHVjtBQUFBQSxJQUFTLEdBQzFDSDtBQUFBQSxXQUFLbUI7QUFBQUEsTUFBTTtBQUFBLE1BQUtuQixLQUFLb0I7QUFBQUEsTUFBTyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBO0FBQUEsTUFDeEJwQixLQUFLc0I7QUFBQUEsTUFBTTtBQUFBLE1BQUMsdUJBQUMsWUFBTyxTQUFTUCxTQUFTLG9CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFBUyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQzdEZixLQUFLcUI7QUFBQUEsTUFBSSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ2IsdUJBQUMsWUFBTyxTQUFTRyxvQkFBb0Isc0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxNQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDdkQsdUJBQUMsWUFBTyxTQUFTVixrQkFBa0Isb0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxTQUx6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUVKO0FBQUNaLEdBeERLSCxNQUFJO0FBQUEwQixLQUFKMUI7QUEwRE4sZUFBZUE7QUFBSSxJQUFBMEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiYmxvZ1NlcnZpY2UiLCJCbG9nIiwiYmxvZyIsImRlbGV0ZUJsb2ciLCJfcyIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidG9nZ2xlVmlzaWJpbGl0eSIsImFkZExpa2UiLCJpZCIsImJsb2dPYmplY3QiLCJ1c2VyIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJsaWtlcyIsInVwZGF0ZSIsImRlbGV0ZVNwZWNpZmljQmxvZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4uL3NlcnZpY2VzL2Jsb2dzJ1xuXG5jb25zdCBCbG9nID0gKHsgYmxvZywgZGVsZXRlQmxvZyB9KSA9PiB7XG4gIGNvbnN0IGJsb2dTdHlsZSA9IHtcbiAgICBwYWRkaW5nVG9wOiAxMCxcbiAgICBwYWRkaW5nTGVmdDogMixcbiAgICBib3JkZXI6ICdzb2xpZCcsXG4gICAgYm9yZGVyV2lkdGg6IDEsXG4gICAgbWFyZ2luQm90dG9tOiA1XG4gIH1cblxuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBoaWRlV2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnbm9uZScgOiAnJyB9XG4gIGNvbnN0IHNob3dXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICcnIDogJ25vbmUnIH1cblxuICBjb25zdCB0b2dnbGVWaXNpYmlsaXR5ID0gKCkgPT4ge1xuICAgIHNldFZpc2libGUoIXZpc2libGUpXG4gIH1cblxuICBjb25zdCBhZGRMaWtlID0gKCkgPT4ge1xuICAgIGNvbnN0IGlkID0gYmxvZy5pZFxuXG4gICAgLy8gY29uc3QgYWxsQmxvZ3MgPSBhd2FpdCBibG9nU2VydmljZS5nZXRBbGwoKVxuXG4gICAgLy8gY29uc3QgY3VycmVudEJsb2cgPSBhbGxCbG9ncy5maW5kKGIgPT4gYi5pZCA9PT0gaWQpXG5cbiAgICBjb25zdCBibG9nT2JqZWN0ID0ge1xuICAgICAgdXNlcjogYmxvZy51c2VyLFxuICAgICAgdGl0bGU6IGJsb2cudGl0bGUsXG4gICAgICBhdXRob3I6IGJsb2cuYXV0aG9yLFxuICAgICAgdXJsOiBibG9nLnVybCxcbiAgICAgIGxpa2VzOiBibG9nLmxpa2VzICsgMSxcbiAgICB9XG5cbiAgICBibG9nU2VydmljZS51cGRhdGUoaWQsIGJsb2dPYmplY3QpO1xuICB9XG5cbiAgY29uc3QgZGVsZXRlU3BlY2lmaWNCbG9nID0gKCkgPT4ge1xuICAgIGNvbnN0IGlkID0gYmxvZy5pZFxuICAgIGRlbGV0ZUJsb2coaWQpO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBzdHlsZT17ey4uLmhpZGVXaGVuVmlzaWJsZSwgLi4uYmxvZ1N0eWxlfX0gY2xhc3NOYW1lPSdibG9nJz5cbiAgICAgICAge2Jsb2cudGl0bGV9XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+dmlldzwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXt7Li4uc2hvd1doZW5WaXNpYmxlLCAuLi5ibG9nU3R5bGV9fT5cbiAgICAgICAge2Jsb2cudGl0bGV9IGJ5IHtibG9nLmF1dGhvcn08YnIvPlxuICAgICAgICBMaWtlczoge2Jsb2cubGlrZXN9IDxidXR0b24gb25DbGljaz17YWRkTGlrZX0+bGlrZTwvYnV0dG9uPjxici8+XG4gICAgICAgIHtibG9nLnVybH08YnIvPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2RlbGV0ZVNwZWNpZmljQmxvZ30+ZGVsZXRlPC9idXR0b24+PGJyLz5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5oaWRlPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiIvVXNlcnMvb3V5YW5nL0RvY3VtZW50cy9MYXVuY2ggU2Nob29sL0Z1bGxTdGFja09wZW4vYmxvZy9ibG9nLWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2cuanN4In0=