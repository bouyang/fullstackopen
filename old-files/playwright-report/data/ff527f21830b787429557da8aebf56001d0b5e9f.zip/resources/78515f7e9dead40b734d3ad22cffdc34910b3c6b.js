import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9f53af8e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = ({
  message,
  error
}) => {
  if (message === null) {
    return null;
  }
  if (error) {
    return /* @__PURE__ */ jsxDEV("div", { className: "error", children: message }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Notification.jsx",
      lineNumber: 9,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { className: "success", children: message }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Notification.jsx",
      lineNumber: 13,
      columnNumber: 12
    }, this);
  }
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007QUFQTixPQUFNQSxvQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUFNLE1BQU07QUFDM0MsTUFBSUQsWUFBWSxNQUFNO0FBQ3BCLFdBQU87QUFBQSxFQUNUO0FBRUEsTUFBSUMsT0FBTztBQUNULFdBQ0UsdUJBQUMsU0FBSSxXQUFVLFNBQ1pELHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUosT0FBTztBQUNMLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLFdBQ1pBLHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFRjtBQUFDRSxLQW5CS0g7QUFxQk4sZUFBZUE7QUFBWSxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTm90aWZpY2F0aW9uIiwibWVzc2FnZSIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG1lc3NhZ2UsIGVycm9yIH0pID0+IHtcbiAgaWYgKG1lc3NhZ2UgPT09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgaWYgKGVycm9yKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdlcnJvcic+XG4gICAgICAgIHttZXNzYWdlfVxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9IGVsc2Uge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT0nc3VjY2Vzcyc+XG4gICAgICAgIHttZXNzYWdlfVxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG4gIFxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb24iXSwiZmlsZSI6Ii9Vc2Vycy9vdXlhbmcvRG9jdW1lbnRzL0xhdW5jaCBTY2hvb2wvRnVsbFN0YWNrT3Blbi9ibG9nL2Jsb2ctZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCJ9