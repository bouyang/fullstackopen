import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=9abf0507";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=9abf0507";
export default require_react();
//# sourceMappingURL=react.js.map
