import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9f53af8e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f53af8e"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import Notification from "/src/components/Notification.jsx?t=1721839692265";
import LoginForm from "/src/components/LoginForm.jsx?t=1721781173648";
import Togglable from "/src/components/Togglable.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [blogTitle, setBlogTitle] = useState("");
  const [user, setUser] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [errorNotification, setErrorNotification] = useState(null);
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
      setErrorMessage("Logged in successfully");
      setErrorNotification(false);
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    } catch (exception) {
      setErrorMessage("Wrong credentials");
      setErrorNotification(true);
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const loginForm = () => {
    return /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "login", children: /* @__PURE__ */ jsxDEV(LoginForm, { username, password, handleUsernameChange: ({
      target
    }) => setUsername(target.value), handlePasswordChange: ({
      target
    }) => setPassword(target.value), handleSubmit: handleLogin }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 60,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 59,
      columnNumber: 12
    }, this);
  };
  const addBlog = async (blogObject) => {
    blogFormRef.current.toggleVisibility();
    let returnedBlog = await blogService.create(blogObject);
    setBlogs(blogs.concat(returnedBlog));
    setErrorNotification(false);
    setErrorMessage(`${blogObject.title} added`);
    setTimeout(() => {
      setErrorMessage(null);
    }, 5e3);
  };
  const blogFormRef = useRef();
  const blogForm = () => /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(
    BlogForm,
    {
      createBlog: addBlog
    },
    void 0,
    false,
    {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 123,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
    lineNumber: 122,
    columnNumber: 26
  }, this);
  const logoutForm = () => {
    return /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 134,
      columnNumber: 12
    }, this);
  };
  const handleLogout = () => {
    window.localStorage.clear();
    setUser(null);
  };
  const deleteBlog = async (id) => {
    await blogService.deleteBlogFromService(id);
    let allBlogs = await blogService.getAll();
    setBlogs(allBlogs);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 146,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: errorMessage, error: errorNotification }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 148,
      columnNumber: 7
    }, this),
    user === null ? loginForm() : /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        user.name,
        " logged-in ",
        logoutForm()
      ] }, void 0, true, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
        lineNumber: 151,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Create new" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
        lineNumber: 152,
        columnNumber: 11
      }, this),
      blogForm(),
      /* @__PURE__ */ jsxDEV("h2", { children: "List of blogs" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
        lineNumber: 155,
        columnNumber: 11
      }, this),
      blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, deleteBlog }, blog.id, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
        lineNumber: 156,
        columnNumber: 30
      }, this))
    ] }, void 0, true, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 150,
      columnNumber: 38
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { children: "Blog app" }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
      lineNumber: 159,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx",
    lineNumber: 145,
    columnNumber: 10
  }, this);
};
_s(App, "8HIqWddbzVR2IrIHo2KQpxQNgtg=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0VROzs7Ozs7Ozs7Ozs7Ozs7OztBQXhFUixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYyxVQUFVQyxXQUFXLElBQUlmLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNnQixVQUFVQyxXQUFXLElBQUlqQixTQUFTLEVBQUU7QUFFM0MsUUFBTSxDQUFDa0IsV0FBV0MsWUFBWSxJQUFJbkIsU0FBUyxFQUFFO0FBSTdDLFFBQU0sQ0FBQ29CLE1BQU1DLE9BQU8sSUFBSXJCLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNzQixjQUFjQyxlQUFlLElBQUl2QixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDd0IsbUJBQW1CQyxvQkFBb0IsSUFBSXpCLFNBQVMsSUFBSTtBQUUvREMsWUFBVSxNQUFNO0FBQ2RPLGdCQUFZa0IsT0FBTyxFQUFFQyxLQUFLZixZQUN4QkMsU0FBVUQsTUFBTSxDQUNsQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUxYLFlBQVUsTUFBTTtBQUNkLFVBQU0yQixpQkFBaUJDLE9BQU9DLGFBQWFDLFFBQVEsbUJBQW1CO0FBQ3RFLFFBQUlILGdCQUFnQjtBQUNsQixZQUFNUixRQUFPWSxLQUFLQyxNQUFNTCxjQUFjO0FBQ3RDUCxjQUFRRCxLQUFJO0FBQ1paLGtCQUFZMEIsU0FBU2QsTUFBS2UsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1sQixRQUFPLE1BQU1YLGFBQWE4QixNQUFNO0FBQUEsUUFDcEN6QjtBQUFBQSxRQUFVRTtBQUFBQSxNQUNaLENBQUM7QUFFRGEsYUFBT0MsYUFBYVUsUUFDbEIscUJBQXFCUixLQUFLUyxVQUFVckIsS0FBSSxDQUMxQztBQUVBWixrQkFBWTBCLFNBQVNkLE1BQUtlLEtBQUs7QUFDL0JkLGNBQVFELEtBQUk7QUFDWkwsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBRWRNLHNCQUFnQix3QkFBd0I7QUFDeENFLDJCQUFxQixLQUFLO0FBQzFCaUIsaUJBQVcsTUFBTTtBQUNmbkIsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixHQUFHLEdBQUk7QUFBQSxJQUVULFNBQVNvQixXQUFXO0FBQ2xCcEIsc0JBQWdCLG1CQUFtQjtBQUNuQ0UsMkJBQXFCLElBQUk7QUFDekJpQixpQkFBVyxNQUFNO0FBQ2ZuQix3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTXFCLFlBQVlBLE1BQU07QUFDdEIsV0FDRSx1QkFBQyxhQUFVLGFBQVksU0FDckIsaUNBQUMsYUFDQyxVQUNBLFVBQ0Esc0JBQXNCLENBQUM7QUFBQSxNQUFFQztBQUFBQSxJQUFPLE1BQU05QixZQUFZOEIsT0FBT0MsS0FBSyxHQUM5RCxzQkFBc0IsQ0FBQztBQUFBLE1BQUVEO0FBQUFBLElBQU8sTUFBTTVCLFlBQVk0QixPQUFPQyxLQUFLLEdBQzlELGNBQWNWLGVBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLNEIsS0FOOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsRUFFSjtBQWNBLFFBQU1XLFVBQVUsT0FBT0MsZUFBZTtBQUNwQ0MsZ0JBQVlDLFFBQVFDLGlCQUFpQjtBQUVyQyxRQUFJQyxlQUFlLE1BQU01QyxZQUFZNkMsT0FBT0wsVUFBVTtBQUV0RG5DLGFBQVNELE1BQU0wQyxPQUFPRixZQUFZLENBQUM7QUFLbkMzQix5QkFBcUIsS0FBSztBQUMxQkYsb0JBQ0csR0FBRXlCLFdBQVdPLEtBQU0sUUFDdEI7QUFFQWIsZUFBVyxNQUFNO0FBQ2ZuQixzQkFBZ0IsSUFBSTtBQUFBLElBQ3RCLEdBQUcsR0FBSTtBQUFBLEVBQ1Q7QUE0QkEsUUFBTTBCLGNBQWMvQyxPQUFPO0FBRTNCLFFBQU1zRCxXQUFXQSxNQUNmLHVCQUFDLGFBQVUsYUFBWSxZQUFXLEtBQUtQLGFBQ3JDO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxZQUFZRjtBQUFBQTtBQUFBQSxJQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFFLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBR0YsUUFBTVUsYUFBYUEsTUFBTTtBQUN2QixXQUNFLHVCQUFDLFlBQU8sU0FBU0MsY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLEVBRXpDO0FBRUEsUUFBTUEsZUFBZUEsTUFBTTtBQUN6QjdCLFdBQU9DLGFBQWE2QixNQUFNO0FBQzFCdEMsWUFBUSxJQUFJO0FBQUEsRUFDZDtBQUVBLFFBQU11QyxhQUFhLE9BQU9DLE9BQU87QUFDL0IsVUFBTXJELFlBQVlzRCxzQkFBc0JELEVBQUU7QUFFMUMsUUFBSUUsV0FBVyxNQUFNdkQsWUFBWWtCLE9BQU87QUFDeENiLGFBQVNrRCxRQUFRO0FBQUEsRUFDbkI7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBRVQsdUJBQUMsZ0JBQWEsU0FBU3pDLGNBQWMsT0FBT0UscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEQ7QUFBQSxJQUU3REosU0FBUyxPQUNSd0IsVUFBVSxJQUNWLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxPQUFHeEI7QUFBQUEsYUFBSzRDO0FBQUFBLFFBQUs7QUFBQSxRQUFZUCxXQUFXO0FBQUEsV0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3ZDLHVCQUFDLFFBQUcsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjO0FBQUEsTUFDYkQsU0FBUztBQUFBLE1BRVYsdUJBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDaEI1QyxNQUFNcUQsSUFBSUMsVUFDVCx1QkFBQyxRQUFtQixNQUFZLGNBQXJCQSxLQUFLTCxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVELENBQ3pEO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVGLHVCQUFDLFlBQU8sd0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLE9BbkJsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0JBO0FBRUo7QUFBQ2xELEdBOUxLRCxLQUFHO0FBQUF5RCxLQUFIekQ7QUFnTU4sZUFBZUE7QUFBRyxJQUFBeUQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsIk5vdGlmaWNhdGlvbiIsIkxvZ2luRm9ybSIsIlRvZ2dsYWJsZSIsIkJsb2dGb3JtIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImJsb2dUaXRsZSIsInNldEJsb2dUaXRsZSIsInVzZXIiLCJzZXRVc2VyIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwiZXJyb3JOb3RpZmljYXRpb24iLCJzZXRFcnJvck5vdGlmaWNhdGlvbiIsImdldEFsbCIsInRoZW4iLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwiaGFuZGxlTG9naW4iLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwibG9naW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5Iiwic2V0VGltZW91dCIsImV4Y2VwdGlvbiIsImxvZ2luRm9ybSIsInRhcmdldCIsInZhbHVlIiwiYWRkQmxvZyIsImJsb2dPYmplY3QiLCJibG9nRm9ybVJlZiIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicmV0dXJuZWRCbG9nIiwiY3JlYXRlIiwiY29uY2F0IiwidGl0bGUiLCJibG9nRm9ybSIsImxvZ291dEZvcm0iLCJoYW5kbGVMb2dvdXQiLCJjbGVhciIsImRlbGV0ZUJsb2ciLCJpZCIsImRlbGV0ZUJsb2dGcm9tU2VydmljZSIsImFsbEJsb2dzIiwibmFtZSIsIm1hcCIsImJsb2ciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCBMb2dpbkZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0xvZ2luRm9ybSdcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSdcbmltcG9ydCBCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQmxvZ0Zvcm0nXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKSBcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBbYmxvZ1RpdGxlLCBzZXRCbG9nVGl0bGVdID0gdXNlU3RhdGUoJycpXG4gIC8vIGNvbnN0IFtibG9nQXV0aG9yLCBzZXRCbG9nQXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICAvLyBjb25zdCBbYmxvZ1VybCwgc2V0QmxvZ1VybF0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2Vycm9yTm90aWZpY2F0aW9uLCBzZXRFcnJvck5vdGlmaWNhdGlvbl0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbihibG9ncyA9PlxuICAgICAgc2V0QmxvZ3MoIGJsb2dzIClcbiAgICApICBcbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oe1xuICAgICAgICB1c2VybmFtZSwgcGFzc3dvcmQsXG4gICAgICB9KVxuXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICdsb2dnZWRCbG9nYXBwVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpXG4gICAgICApXG5cbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ0xvZ2dlZCBpbiBzdWNjZXNzZnVsbHknKVxuICAgICAgc2V0RXJyb3JOb3RpZmljYXRpb24oZmFsc2UpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICB9LCA1MDAwKVxuICAgICAgXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ1dyb25nIGNyZWRlbnRpYWxzJylcbiAgICAgIHNldEVycm9yTm90aWZpY2F0aW9uKHRydWUpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGxvZ2luRm9ybSA9ICgpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD0nbG9naW4nPlxuICAgICAgICA8TG9naW5Gb3JtXG4gICAgICAgICAgdXNlcm5hbWU9e3VzZXJuYW1lfVxuICAgICAgICAgIHBhc3N3b3JkPXtwYXNzd29yZH1cbiAgICAgICAgICBoYW5kbGVVc2VybmFtZUNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgaGFuZGxlUGFzc3dvcmRDaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgIGhhbmRsZVN1Ym1pdD17aGFuZGxlTG9naW59XG4gICAgICAgIC8+XG4gICAgICA8L1RvZ2dsYWJsZT5cbiAgICApXG4gIH1cblxuICAvLyBjb25zdCBoYW5kbGVUaXRsZUNoYW5nZSA9IChldmVudCkgPT4ge1xuICAvLyAgIHNldEJsb2dUaXRsZShldmVudC50YXJnZXQudmFsdWUpO1xuICAvLyB9XG5cbiAgLy8gY29uc3QgaGFuZGxlQXV0aG9yQ2hhbmdlID0gKGV2ZW50KSA9PiB7XG4gIC8vICAgc2V0QmxvZ0F1dGhvcihldmVudC50YXJnZXQudmFsdWUpO1xuICAvLyB9XG5cbiAgLy8gY29uc3QgaGFuZGxlVXJsQ2hhbmdlID0gKGV2ZW50KSA9PiB7XG4gIC8vICAgc2V0QmxvZ1VybChldmVudC50YXJnZXQudmFsdWUpO1xuICAvLyB9XG5cbiAgY29uc3QgYWRkQmxvZyA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XG4gICAgYmxvZ0Zvcm1SZWYuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KClcbiAgICBcbiAgICBsZXQgcmV0dXJuZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlKGJsb2dPYmplY3QpO1xuXG4gICAgc2V0QmxvZ3MoYmxvZ3MuY29uY2F0KHJldHVybmVkQmxvZykpXG4gICAgLy8gc2V0QmxvZ1RpdGxlKCcnKVxuICAgIC8vIHNldEJsb2dBdXRob3IoJycpXG4gICAgLy8gc2V0QmxvZ1VybCgnJylcblxuICAgIHNldEVycm9yTm90aWZpY2F0aW9uKGZhbHNlKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UoXG4gICAgICBgJHtibG9nT2JqZWN0LnRpdGxlfSBhZGRlZGBcbiAgICApXG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxuICAgIH0sIDUwMDApXG4gIH1cblxuICAvLyBjb25zdCBhZGRCbG9nID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gIC8vICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcblxuICAvLyAgIGNvbnN0IGJsb2dPYmplY3QgPSB7XG4gIC8vICAgICB0aXRsZTogYmxvZ1RpdGxlLFxuICAvLyAgICAgYXV0aG9yOiBibG9nQXV0aG9yLFxuICAvLyAgICAgdXJsOiBibG9nVXJsLFxuICAvLyAgIH1cblxuICAvLyAgIGxldCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZ09iamVjdCk7XG5cbiAgLy8gICBzZXRCbG9ncyhibG9ncy5jb25jYXQocmV0dXJuZWRCbG9nKSlcbiAgLy8gICBzZXRCbG9nVGl0bGUoJycpXG4gIC8vICAgc2V0QmxvZ0F1dGhvcignJylcbiAgLy8gICBzZXRCbG9nVXJsKCcnKVxuXG4gIC8vICAgc2V0RXJyb3JOb3RpZmljYXRpb24oZmFsc2UpO1xuICAvLyAgIHNldEVycm9yTWVzc2FnZShcbiAgLy8gICAgIGAke2Jsb2dUaXRsZX0gYWRkZWRgXG4gIC8vICAgKVxuXG4gIC8vICAgc2V0VGltZW91dCgoKSA9PiB7XG4gIC8vICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcbiAgLy8gICB9LCA1MDAwKVxuICAvLyB9XG5cbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYoKVxuXG4gIGNvbnN0IGJsb2dGb3JtID0gKCkgPT4gKFxuICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9XCJuZXcgYmxvZ1wiIHJlZj17YmxvZ0Zvcm1SZWZ9PlxuICAgICAgPEJsb2dGb3JtXG4gICAgICAgIGNyZWF0ZUJsb2c9e2FkZEJsb2d9XG4gICAgICAgIC8vIG9uU3VibWl0PXthZGRCbG9nfVxuICAgICAgICAvLyBibG9nVGl0bGU9e2Jsb2dUaXRsZX1cbiAgICAgICAgLy8gaGFuZGxlVGl0bGVDaGFuZ2U9e2hhbmRsZVRpdGxlQ2hhbmdlfVxuICAgICAgICAvLyBibG9nQXV0aG9yPXtibG9nQXV0aG9yfVxuICAgICAgICAvLyBoYW5kbGVBdXRob3JDaGFuZ2U9e2hhbmRsZUF1dGhvckNoYW5nZX1cbiAgICAgICAgLy8gYmxvZ1VybD17YmxvZ1VybH1cbiAgICAgICAgLy8gaGFuZGxlVXJsQ2hhbmdlPXtoYW5kbGVVcmxDaGFuZ2V9XG4gICAgICAvPlxuICAgIDwvVG9nZ2xhYmxlPlxuICApXG5cbiAgY29uc3QgbG9nb3V0Rm9ybSA9ICgpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PmxvZ291dDwvYnV0dG9uPlxuICAgIClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLmNsZWFyKClcbiAgICBzZXRVc2VyKG51bGwpXG4gIH1cblxuICBjb25zdCBkZWxldGVCbG9nID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgYXdhaXQgYmxvZ1NlcnZpY2UuZGVsZXRlQmxvZ0Zyb21TZXJ2aWNlKGlkKVxuXG4gICAgbGV0IGFsbEJsb2dzID0gYXdhaXQgYmxvZ1NlcnZpY2UuZ2V0QWxsKClcbiAgICBzZXRCbG9ncyhhbGxCbG9ncylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5ibG9nczwvaDI+XG5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17ZXJyb3JNZXNzYWdlfSBlcnJvcj17ZXJyb3JOb3RpZmljYXRpb259IC8+XG5cbiAgICAgIHt1c2VyID09PSBudWxsID9cbiAgICAgICAgbG9naW5Gb3JtKCkgOlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxwPnt1c2VyLm5hbWV9IGxvZ2dlZC1pbiB7bG9nb3V0Rm9ybSgpfTwvcD5cbiAgICAgICAgICA8aDI+Q3JlYXRlIG5ldzwvaDI+XG4gICAgICAgICAge2Jsb2dGb3JtKCl9XG4gICAgICAgICAgXG4gICAgICAgICAgPGgyPkxpc3Qgb2YgYmxvZ3M8L2gyPlxuICAgICAgICAgIHtibG9ncy5tYXAoYmxvZyA9PlxuICAgICAgICAgICAgPEJsb2cga2V5PXtibG9nLmlkfSBibG9nPXtibG9nfSBkZWxldGVCbG9nPXtkZWxldGVCbG9nfS8+XG4gICAgICAgICAgKX1cbiAgICAgICAgICBcbiAgICAgICAgPC9kaXY+XG4gICAgICB9XG4gICAgICA8Zm9vdGVyPkJsb2cgYXBwPC9mb290ZXI+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiIvVXNlcnMvb3V5YW5nL0RvY3VtZW50cy9MYXVuY2ggU2Nob29sL0Z1bGxTdGFja09wZW4vYmxvZy9ibG9nLWZyb250ZW5kL3NyYy9BcHAuanN4In0=