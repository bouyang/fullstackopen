import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9f53af8e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=09fa3a5b"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const LoginForm = ({
  handleSubmit,
  handleUsernameChange,
  handlePasswordChange,
  username,
  password
}) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
      lineNumber: 10,
      columnNumber: 6
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", value: username, onChange: handleUsernameChange }, void 0, false, {
          fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
          lineNumber: 15,
          columnNumber: 10
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
        lineNumber: 13,
        columnNumber: 8
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, onChange: handlePasswordChange }, void 0, false, {
          fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
          lineNumber: 19,
          columnNumber: 10
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
        lineNumber: 17,
        columnNumber: 8
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
        fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
        lineNumber: 21,
        columnNumber: 8
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
      lineNumber: 12,
      columnNumber: 6
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
};
_c = LoginForm;
LoginForm.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  handleUsernameChange: PropTypes.func.isRequired,
  handlePasswordChange: PropTypes.func.isRequired,
  username: PropTypes.string.isRequired,
  password: PropTypes.string.isRequired
};
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ouyang/Documents/Launch School/FullStackOpen/blog/blog-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV0s7QUFYTCxPQUFPQSxvQkFBZTtBQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVsQyxNQUFNQyxZQUFZQSxDQUFDO0FBQUEsRUFDakJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0QsTUFBTTtBQUNOLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFFVCx1QkFBQyxVQUFLLFVBQVVKLGNBQ2Q7QUFBQSw2QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsZUFBWSxZQUNaLE9BQU9HLFVBQ1AsVUFBVUYsd0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdpQztBQUFBLFdBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRix1QkFBQyxXQUNDLGVBQVksWUFDWixNQUFLLFlBQ0wsT0FBT0csVUFDUCxVQUFVRix3QkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSWlDO0FBQUEsV0FObkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFGO0FBQUEsTUFDRSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLFNBbEI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVCQTtBQUVIO0FBQUNHLEtBakNLTjtBQW1DTkEsVUFBVU8sWUFBWTtBQUFBLEVBQ3BCTixjQUFjRixVQUFVUyxLQUFLQztBQUFBQSxFQUM3QlAsc0JBQXNCSCxVQUFVUyxLQUFLQztBQUFBQSxFQUNyQ04sc0JBQXNCSixVQUFVUyxLQUFLQztBQUFBQSxFQUNyQ0wsVUFBVUwsVUFBVVcsT0FBT0Q7QUFBQUEsRUFDM0JKLFVBQVVOLFVBQVVXLE9BQU9EO0FBQzdCO0FBRUEsZUFBZVQ7QUFBUyxJQUFBTTtBQUFBSyxhQUFBTCxJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwiTG9naW5Gb3JtIiwiaGFuZGxlU3VibWl0IiwiaGFuZGxlVXNlcm5hbWVDaGFuZ2UiLCJoYW5kbGVQYXNzd29yZENoYW5nZSIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJfYyIsInByb3BUeXBlcyIsImZ1bmMiLCJpc1JlcXVpcmVkIiwic3RyaW5nIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW5Gb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IExvZ2luRm9ybSA9ICh7XG4gIGhhbmRsZVN1Ym1pdCxcbiAgaGFuZGxlVXNlcm5hbWVDaGFuZ2UsXG4gIGhhbmRsZVBhc3N3b3JkQ2hhbmdlLFxuICB1c2VybmFtZSxcbiAgcGFzc3dvcmRcbiB9KSA9PiB7XG4gcmV0dXJuIChcbiAgIDxkaXY+XG4gICAgIDxoMj5Mb2dpbjwvaDI+XG5cbiAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgPGRpdj5cbiAgICAgICAgIHVzZXJuYW1lXG4gICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3VzZXJuYW1lJ1xuICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVVc2VybmFtZUNoYW5nZX1cbiAgICAgICAgIC8+XG4gICAgICAgPC9kaXY+XG4gICAgICAgPGRpdj5cbiAgICAgICAgIHBhc3N3b3JkXG4gICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3Bhc3N3b3JkJ1xuICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXNzd29yZENoYW5nZX1cbiAgICAgICAgIC8+XG4gICAgIDwvZGl2PlxuICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmxvZ2luPC9idXR0b24+XG4gICAgIDwvZm9ybT5cbiAgIDwvZGl2PlxuIClcbn1cblxuTG9naW5Gb3JtLnByb3BUeXBlcyA9IHtcbiAgaGFuZGxlU3VibWl0OiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBoYW5kbGVVc2VybmFtZUNoYW5nZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgaGFuZGxlUGFzc3dvcmRDaGFuZ2U6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIHVzZXJuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIHBhc3N3b3JkOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWRcbn1cblxuZXhwb3J0IGRlZmF1bHQgTG9naW5Gb3JtIl0sImZpbGUiOiIvVXNlcnMvb3V5YW5nL0RvY3VtZW50cy9MYXVuY2ggU2Nob29sL0Z1bGxTdGFja09wZW4vYmxvZy9ibG9nLWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0xvZ2luRm9ybS5qc3gifQ==